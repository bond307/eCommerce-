<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <!------- owl cursel ----->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="../style.css">
    <!-------- fontawsome ----->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/fontawesome.min.css">

    <title>Customer Login</title>
</head>

<body>

    <!------ top header part ------>
    <section id="top-header">

        <div class="row">
            <div class="top-menu">
                <ul>
                    <li><a href="">Sing In</a><small>Or</small></li>
                    <li><a href="">Create an account</a></li>
                </ul>
            </div>
        </div>
    </section>
    <!--------################################################################################################################### End Section ####################################---->


    <!------ 2nd header part ------>
    <section id="secound-header">

        <div class="row">
            <div class="logo-part">
                <img src="../images/logo.png" alt="">
            </div>
            <div class="secound-header-menu-part">
                <ul>
                    <li><a href=""><i class="fa fa-search"></i> Search</a></li>
                    <li><a href=""><i class="fa fa-user"></i> Account</a></li>
                    <li><a href=""><i class="fa fa-shopping-basket"></i> Cart <span>10</span></a></li>
                </ul>
            </div>
        </div>
    </section>
    <!--------################################################################################################################### End 2nd header ####################################---->

    <!------ 2nd header part ------>
    <section id="pc-category">

        <div class="row">
            <div class="category">
                <ul>
                    <li> TOBACCOS</li>
                    <li> CIGARATTES</li>
                </ul>
            </div>
        </div>
    </section>
    <!--------################################################################################################################### End 2nd header ####################################---->



<section id="header-support-bar">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <ul>
                    <li><i class="fa fa-shopping-bag"></i> One time delivery</li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul>
                     <li><i class="fa fa-phone"></i> Order On: 014778544885</li>
                </ul>
            </div>
            <div class="col-md-3">
                 <ul>
                     <li><i class="fa fa-hand-o-up"></i> Click & Colloct from Otlye</li>
                 </ul>
            </div>
            <div class="col-md-3">
                 <ul>
                     <li>Excellent <small><b>4.8</b> out of 5</small></li>
                 </ul>
            </div>
        </div>
    </div>
</section>

    <!--------################################################################################################################### Statrt body part ####################################---->

    <section id="my-account-title">

        <div class="container">
            <div class="my-account-title-content">
                <p>My Account</p>
            </div>
        </div>

    </section>
    <!--------################################################################################################################### End 2nd header ####################################---->



    <section id="account-page-body">

        <div class="container">
            <div class="row">
                <div class="col-md-6 login-part">
                    <h2>Customer Login</h2>
                    <h4>REGISTERED CUSTOMERS</h4>
                    <hr>
                    <p>If you have an account, sign in with your email address.</p>
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Email <span>*</span></label>
                            <input type="email" class="form-control" placeholder="Email...">
                        </div>
                        <div class="form-group">
                            <label>Password <span>*</span></label>
                            <input type="password" class="form-control">
                        </div>

                        <div class="form-group">
                            <label><input type="checkbox" class="checkbox checked"> Remember Me</label>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <button class="btn btn-main">Sign In</button>
                            </div>
                            <div class="col-md-9">
                                <label class="account-forget-pass"><a href="">Forget your Password?</a></label>
                            </div>
                        </div>

                    </form>
                </div>
                <div class="col-md-6 create-an-account-part">

                    <h4>NEW CUSTOMERS</h4>
                    <hr>
                    <p>Creating an account has many benefits: check out faster, keep more than one address, track orders and more.</p>
                    <button class="btn btn-secoundery">Create an new account</button>
                </div>
            </div>
        </div>

    </section>
    <!--------################################################################################################################### End 2nd header ####################################---->




    <!--------################################################################################################################### Footer ####################################---->

    <section id="footer">

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 customer-service">
                    
                    <ul>
                       <li><h4>CUSTOMER SERVICES</h4></li>
                        <li>Monday through Friday</li>
                        <li>9:30am - 3:30pm</li><br><br><br>

                        <li><b><a href="">0113 217 7723</a></b></li>
                        <li><b><a href="">Send us an Email</a></b></li><br><br><br>

                        <li>Greens Holdings UK Limited</li>
                        <li>Unit E2 Otley Mills</li>
                        <li>Ilkley Road, Otley</li>
                        <li>LS21 3EE, UK.</li>
                    </ul>
                </div>
                <div class="col-md-3">
                  
                    <ul>
                       <li><h4>CUSTOMER SERVICES</h4></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>
 Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    
                    <ul>
                       <li><h4>CUSTOMER SERVICES</h4></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                        <li><a href=""><i class="fa fa-angle-double-right"></i>&nbsp Smoking Accessories</a></li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <img src="../images/payment-icons.png" alt="">
                </div>

            </div>
        </div>

    </section>
     <!--------################################################################################################################### end footer ####################################---->



    <section id="footer-age-check">
        <div class="container">
            <div class="footer-age-check">
                <div class="footer-age">
                    <p>18+</p>
                </div>
                <div class="footer-age-content">
                    <p>This website contains images of Tobacco and other age restricted products. If you are under 18, please exit now.</p>
                </div>
            </div>
        </div>
    </section>
    <!--------################################################################################################################### end footer ####################################---->
    
    
    <section id="footer-copy-right">
        <div class="container">
            <div class="copy-right-section">
                <p>© 2010-2021 Greens Holdings UK Limited trading as Smoke-King.co.uk.</p>
                <p>Registered in England & Wales Company No. 10622615. All Rights Reserved. E&OE.</p>
            </div>
        </div>
    </section>

</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>

</html>